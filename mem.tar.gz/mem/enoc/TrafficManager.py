
class Module():
    type = 'Module'
    cxx_header = "mem/enoc/module.h"

class TrafficManager(Module):
    type = 'TrafficManager'
    cxx_header = "mem/enoc/trafficmanager.h"
